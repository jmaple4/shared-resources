# XboxU project
Pull down the sketch file and start making your own UIs of the Xbox One platform. This was designed as part of an idea that I wanted to open source for [kids to lean how to code on Xbox](https://medium.com/product-design-adventures/using-xbox-to-teach-kids-how-to-code-61d666ffa941).

![Preview image](https://github.com/jmaple4/shared-resources/blob/master/XboxU/preview.png)

### Dependencies

[Sketch](http://bohemiancoding.com/sketch/) and the [Selewik font](https://github.com/winjs/winstrap/tree/master/src/fonts).
